require_relative "employee"

class Manager < Employee
    
    def team
        members = []
    end

    def bonus(multiplier)
        salaries = 0
        members.each do |member|
            salaries += member.salary
        end
        salaries * multiplier
    end

end